# Good markdown

Images are using ![https](https://example.com/path.jpg) or they ![are relative](img/path.jpg).
